#:property PublishAot=false
Directory.CreateDirectory( "Assets/ZipDemo" );
File.WriteAllText( $"Assets/ZipDemo/Install-{args[0]}.txt", "I'm the install manual of CKt.SomeApp version '{args[0]}'." );
File.WriteAllText( $"Assets/ZipDemo/AnotherFile.txt", "Another file..." );
