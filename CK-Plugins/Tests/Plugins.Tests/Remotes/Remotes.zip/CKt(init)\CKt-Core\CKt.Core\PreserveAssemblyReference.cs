
namespace CKt.Core;

public record PreserveAssemblyReference( CommunityToolkit.HighPerformance.Box<int> CommunityToolkit,
                                         Microsoft.IO.RecyclableMemoryStream RecyclableMemoryStream );
