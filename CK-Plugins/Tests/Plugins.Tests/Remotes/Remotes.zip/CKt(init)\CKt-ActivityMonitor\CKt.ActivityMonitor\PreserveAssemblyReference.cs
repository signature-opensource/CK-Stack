using System;

namespace CKt.ActivityMonitor;

public record PreserveAssemblyReference( CKt.Core.PreserveAssemblyReference Core );
