using System;

namespace CKt.Sample.Monitoring;

public record PreserveAssemblyReference( CKt.Monitoring.PreserveAssemblyReference Monitoring,
                                         CKt.PerfectEvent.PreserveAssemblyReference PerfectEvent );
        